#include "pvz/GameObject/Gameend.hpp"
Gameend::Gameend():GameObject(IMGID_ZOMBIES_WON,WINDOW_WIDTH/2,WINDOW_HEIGHT/2,LAYER_UI,564,468,ANIMID_NO_ANIMATION,Object_type::Other){}
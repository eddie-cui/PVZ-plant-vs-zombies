#ifndef SEEDWALLNUT_HPP
#define SEEDWALLNUT_HPP
#include "pvz/GameObject/Seed.hpp"
class SeedWallnut:public Seed{
private:

public:
    SeedWallnut(std::shared_ptr<GameWorld>gw);

};
#endif
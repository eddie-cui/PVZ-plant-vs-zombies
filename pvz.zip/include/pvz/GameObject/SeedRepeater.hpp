#ifndef SEEDREPEATER_HPP
#define SEEDREPEATER_HPP
#include "pvz/GameObject/Seed.hpp"
class SeedRepeater:public Seed{
private:

public:
    SeedRepeater(std::shared_ptr<GameWorld>gw);

};

#endif
#ifndef SHOVEL_HPP
#define SHOVEL_HPP
#include "pvz/GameObject/Seed.hpp"
class Shovel : public Seed {
private:

public:
    Shovel(std::shared_ptr<GameWorld>gw);

};

#endif
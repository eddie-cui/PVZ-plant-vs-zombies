#ifndef SEEDSUNFLOWER_HPP
#define SEEDSUNFLOWER_HPP
#include "pvz/GameObject/Seed.hpp"
class SeedSunflower : public Seed {
private:

public:
    SeedSunflower(std::shared_ptr<GameWorld>gw);

};
#endif
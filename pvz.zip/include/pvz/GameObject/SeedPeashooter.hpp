#ifndef SEEDPEASHOOTER_HPP
#define SEEDPEASHOOTER_HPP
#include"pvz/GameObject/Seed.hpp"
class SeedPeashooter:public Seed{
private:

public:
    SeedPeashooter(std::shared_ptr<GameWorld>gw);

};

#endif
#ifndef GAMEEND_HPP
#define GAMEEND_HPP
#include "pvz/GameObject/GameObject.hpp"
class Gameend:public GameObject{
public:
Gameend();
void Update()override{}
void Init()override{}
void OnClick()override{}
};
#endif
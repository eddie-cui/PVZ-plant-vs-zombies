#ifndef SEEDCHERRYBOMB_HPP
#define SEEDCHERRYBOMB_HPP
#include "pvz/GameObject/Seed.hpp"
class SeedCherrybomb: public Seed{

public:
    SeedCherrybomb(std::shared_ptr<GameWorld>gw);
};
#endif